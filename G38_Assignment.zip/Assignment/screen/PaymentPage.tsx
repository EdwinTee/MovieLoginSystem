import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { useRoute, RouteProp } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';

// Define the navigation stack parameter list
type RootStackParamList = {
  ConfirmBookingPage: {
    selectedSeats: string[];
    movieTitle: string;
    timeSlot: string;
  };
  PaymentPage: {
    total: number;
  };
};

// Define the route and navigation prop types
type RoutePropType = RouteProp<RootStackParamList, 'PaymentPage'>;
type NavigationProp = StackNavigationProp<RootStackParamList, 'PaymentPage'>;

const PaymentPage = () => {
  const route = useRoute<RoutePropType>();
  const { total } = route.params;

  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvv, setCvv] = useState('');

  const handlePayment = () => {
    if (cardNumber && expiry && cvv) {
      Alert.alert('Payment Successful', `You have paid RM ${total.toFixed(2)}`);
    } else {
      Alert.alert('Error', 'Please fill in all payment details.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Card Number</Text>
      <TextInput
        style={styles.input}
        keyboardType="numeric"
        onChangeText={setCardNumber}
        placeholder="Enter card number"
        placeholderTextColor="#888"
      />

      <Text style={styles.label}>Expiry Date (MM/YY)</Text>
      <TextInput
        style={styles.input}
        onChangeText={setExpiry}
        placeholder="MM/YY"
        placeholderTextColor="#888"
      />

      <Text style={styles.label}>CVV</Text>
      <TextInput
        style={styles.input}
        keyboardType="numeric"
        secureTextEntry
        onChangeText={setCvv}
        placeholder="Enter CVV"
        placeholderTextColor="#888"
      />

      <TouchableOpacity onPress={handlePayment} style={styles.payBtn}>
        <Text style={styles.payText}>Pay RM {total.toFixed(2)}</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { padding: 20, backgroundColor: '#000', flex: 1 },
  label: { color: '#fff', marginTop: 10 },
  input: { backgroundColor: '#fff', padding: 10, borderRadius: 5, marginTop: 5 },
  payBtn: { backgroundColor: 'green', marginTop: 30, padding: 15, borderRadius: 10, alignItems: 'center' },
  payText: { color: '#fff', fontSize: 16 },
});

export default PaymentPage;