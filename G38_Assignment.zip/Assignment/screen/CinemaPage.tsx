import React, { useState } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';


// Define the navigation stack parameter list
type RootStackParamList = {
  SelectSeatsPage: {
    movieId: string;
    movieTitle: string;
    timeSlot: string;
  };
};

// Define the navigation prop type
type NavigationProp = StackNavigationProp<RootStackParamList, 'SelectSeatsPage'>;

// Define the cinema and movie data types
type Movie = {
  id: string;
  title: string;
  timeSlots: string[];
};

type Cinema = {
  id: string;
  name: string;
  movies: Movie[];
};

// Cinema data
const cinemaData: Cinema[] = [
  {
    id: 'cinema-1',
    name: 'Sunway Velocity',
    movies: [
      {
        id: 'movie-1',
        title: 'Uncharted',
        timeSlots: ['12:00 PM-3:00 PM', '3:00 PM-6:00 PM', '6:00 PM-9:00 PM'],
      },
      {
        id: 'movie-2',
        title: 'Maleficient',
        timeSlots: ['1:00 PM-4:00 PM', '4:00 PM-7:00 PM', '7:00 PM-10:00 PM'],
      },
    ],
  },
  {
    id: 'cinema-2',
    name: '1 Shamelin',
    movies: [
      {
        id: 'movie-3',
        title: 'Avengers End-game',
        timeSlots: ['11:00 AM-2:00 PM', '2:00 PM-5:00 PM', '5:00 PM-8:00 PM'],
      },
    ],
  },
  {
    id: 'cinema-3',
    name: 'My Town',
    movies: [
      {
        id: 'movie-4',
        title: 'Venom',
        timeSlots: ['9:00 AM-12:00 PM', '12:00 PM-3:00 PM', '3:00 PM-6:00 PM'],
      },
    ],
  },
];

const CinemaPage: React.FC = () => {
  const navigation = useNavigation<NavigationProp>();
  const [expandedCinemaId, setExpandedCinemaId] = useState<string | null>(null);

  const handleCinemaPress = (cinemaId: string) => {
    setExpandedCinemaId(expandedCinemaId === cinemaId ? null : cinemaId);
  };

  const handleSelectMovie = (movieId: string, movieTitle: string, timeSlot: string) => {
    navigation.navigate('SelectSeatsPage', {
      movieId,
      movieTitle,
      timeSlot,
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Cinemas</Text>
      <FlatList
        data={cinemaData}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.cinemaSection}>
            <TouchableOpacity
              style={styles.cinemaButton}
              onPress={() => handleCinemaPress(item.id)}
            >
              <Text style={styles.cinemaName}>{item.name}</Text>
            </TouchableOpacity>

            {expandedCinemaId === item.id && (
              <View style={styles.moviesList}>
                {item.movies.map((movie) => (
                  <View key={movie.id} style={styles.movieBlock}>
                    <Text style={styles.movieTitle}>{movie.title}</Text>
                    <View style={styles.timeSlotRow}>
                      {movie.timeSlots.map((timeSlot, index) => (
                        <TouchableOpacity
                          key={index}
                          onPress={() => handleSelectMovie(movie.id, movie.title, timeSlot)}
                          style={styles.timeSlotButton}
                        >
                          <Text style={styles.timeSlotText}>{timeSlot}</Text>
                        </TouchableOpacity>
                      ))}
                    </View>
                  </View>
                ))}
              </View>
            )}
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
    padding: 16,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 16,
  },
  cinemaSection: {
    marginBottom: 12,
  },
  cinemaButton: {
    backgroundColor: '#d32f2f',
    padding: 12,
    borderRadius: 8,
  },
  cinemaName: {
    fontSize: 18,
    color: 'white',
  },
  moviesList: {
    paddingLeft: 12,
    marginTop: 8,
  },
  movieBlock: {
    marginBottom: 12,
  },
  movieTitle: {
    fontSize: 16,
    color: 'white',
    marginBottom: 4,
  },
  timeSlotRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  timeSlotButton: {
    backgroundColor: 'white',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    marginRight: 8,
    marginBottom: 8,
  },
  timeSlotText: {
    color: 'black',
    fontWeight: 'bold',
  },
});

export default CinemaPage;