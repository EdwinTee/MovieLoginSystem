import React from 'react'
import {View,Text} from 'react-native'


const SearchScreen = () => {
    return(
        <View>
            <Text>Search</Text>
        </View>
    )
}

export default SearchScreen;