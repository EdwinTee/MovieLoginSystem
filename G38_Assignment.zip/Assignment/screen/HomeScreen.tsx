import React from 'react';
import { View, Text, TextInput, FlatList, Image, TouchableOpacity, ScrollView } from 'react-native';
import styles from './styles';
import Icon from 'react-native-vector-icons/Ionicons';
import { StackNavigationProp } from '@react-navigation/stack';

const movies = [
  {
    id: '1',
    title: 'Fast X',
    rating: '7.3',
    votes: '1895',
    genres: ['Crime', 'Thriller'],
    image: require('../android/app/src/main/assets/fastx.jpg'),
    duration: '2h 10m',
    releaseDate: '19 May 2023',
    description: "Dom Toretto and his family are targeted by the vengeful son of drug kingpin Hernan Reyes.",
  },
  {
    id: '2',
    title: 'Maleficent',
    rating: '6.9',
    votes: '1379',
    genres: ['Fantasy', 'Fairy Tale'],
    image: require('../android/app/src/main/assets/maleficent.jpg'),
    duration: '2h 10m',
    releaseDate: '19 May 2023',
    description: 'Dom Toretto and his family are targeted by the vengeful son of drug kingpin Hernan Reyes.',
  },
  {
    id: '3',
    title: 'Uncharted',
    rating: '6.3',
    votes: '773',
    genres: ['Action', 'Adventure'],
    image: require('../android/app/src/main/assets/uncharted.jpg'),
    duration: '2h 10m',
    releaseDate: '19 May 2023',
    description: 'Dom Toretto and his family are targeted by the vengeful son of drug kingpin Hernan Reyes.',
  },
  {
    id: '4',
    title: 'Super Mario Bros',
    rating: '6.3',
    votes: '773',
    genres: ['Action', 'Adventure'],
    image: require('../android/app/src/main/assets/supermario.jpg'),
    duration: '2h 10m',
    releaseDate: '19 May 2023',
    description: 'Dom Toretto and his family are targeted by the vengeful son of drug kingpin Hernan Reyes.',
  },
  {
    id: '5',
    title: 'Inside Out 2',
    rating: 'N/A',
    votes: '0',
    genres: ['Action', 'Adventure'],
    image: require('../android/app/src/main/assets/insideout.jpg'),
    duration: '2h 10m',
    releaseDate: '19 May 2023',
    description: 'Dom Toretto and his family are targeted by the vengeful son of drug kingpin Hernan Reyes.',
  },
  
];

const popularMovies = [
  {
    id: '1',
    title: 'Avatar 2',
    rating: '8.1',
    votes: '2500',
    genres: ['Sci-Fi', 'Adventure'],
    image: require('../android/app/src/main/assets/avatar2.jpg'),
    duration: '2h 10m',
    releaseDate: '19 May 2023',
    description: 'Dom Toretto and his family are targeted by the vengeful son of drug kingpin Hernan Reyes.',
  },
  {
    id: '2',
    title: 'Joker',
    rating: '8.5',
    votes: '3000',
    genres: ['Crime', 'Drama'],
    image: require('../android/app/src/main/assets/joker.jpg'),
    duration: '2h 10m',
    releaseDate: '19 May 2023',
    description: 'Dom Toretto and his family are targeted by the vengeful son of drug kingpin Hernan Reyes.',
  },
  {
    id: '3',
    title: 'Spiderman',
    rating: 'N/A',
    votes: '0',
    genres: ['Action', 'Adventure'],
    image: require('../android/app/src/main/assets/spiderman.jpg'),
    duration: '2h 10m',
    releaseDate: '19 May 2023',
    description: 'Dom Toretto and his family are targeted by the vengeful son of drug kingpin Hernan Reyes.',
  },
  {
    id: '4',
    title: 'Avengers',
    rating: 'N/A',
    votes: '0',
    genres: ['Action', 'Adventure'],
    image: require('../android/app/src/main/assets/avengers.jpg'),
    duration: '2h 10m',
    releaseDate: '19 May 2023',
    description: 'Dom Toretto and his family are targeted by the vengeful son of drug kingpin Hernan Reyes.',
  },
];

const upcomingMovies = [
  {
    id: '1',
    title: 'John Wick 4',
    rating: 'N/A',
    votes: '0',
    genres: ['Action', 'Superhero'],
    image: require('../android/app/src/main/assets/johnwick.jpg'),
    duration: '2h 10m',
    releaseDate: '19 May 2023',
    description: 'Dom Toretto and his family are targeted by the vengeful son of drug kingpin Hernan Reyes.',
  },
  {
    id: '2',
    title: 'Demon Slayer',
    rating: 'N/A',
    votes: '0',
    genres: ['Action', 'Adventure'],
    image: require('../android/app/src/main/assets/demonslayer.jpg'),
    duration: '2h 10m',
    releaseDate: '19 May 2023',
    description: 'Dom Toretto and his family are targeted by the vengeful son of drug kingpin Hernan Reyes.',
  },
  {
    id: '3',
    title: 'Ne Zha 2',
    rating: 'N/A',
    votes: '0',
    genres: ['Action', 'Adventure'],
    image: require('../android/app/src/main/assets/nezha2.jpg'),
    duration: '2h 10m',
    releaseDate: '19 May 2023',
    description: 'Dom Toretto and his family are targeted by the vengeful son of drug kingpin Hernan Reyes.',
  },
];

type RootStackParamList = {
  MovieDetail: { movie: { id: string; title: string; rating: string; votes: string; genres: string[]; image: any; duration: string; releaseDate: string; description: string } };
  CinemaPage: undefined; // No parameters for CinemaPage
};

type NavigationProp = StackNavigationProp<RootStackParamList, 'MovieDetail'>;

const HomeScreen = ({navigation}) => {

  const renderMovieItem = ({ item }: { item: typeof movies[0] }) => (
    <TouchableOpacity
     style={styles.movieCard}
     onPress={() => navigation.navigate('MovieDetail', { movie: item })}
     >
      <Image source={item.image} style={styles.movieImage} />
      <Text style={styles.movieTitle}>{item.title}</Text>
      <Text style={styles.movieRating}>
        ⭐ {item.rating} ({item.votes})
      </Text>
      <View style={styles.genreContainer}>
        {item.genres.map((genre, index) => (
          <Text key={index} style={styles.genre}>
            {genre}
          </Text>
        ))}
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <ScrollView>
        {/* Search Bar */}
        <View style={styles.searchBar}>
          <TextInput placeholder="Search your Movies..." placeholderTextColor="#888" style={styles.searchInput} />
          <Icon name="search" size={20} color="#fff" />
        </View>

        {/* Now Playing Section */}
        <Text style={styles.sectionTitle}>Now Playing</Text>
        <FlatList
          data={movies}
          renderItem={renderMovieItem}
          keyExtractor={(item) => item.id}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.movieList}
        />

        {/* Popular Now Section */}
        <Text style={styles.sectionTitle}>Popular Now</Text>
        <FlatList
          data={popularMovies}
          renderItem={renderMovieItem}
          keyExtractor={(item) => item.id}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.movieList}
        />

        {/* Upcoming Movies Section */}
        <Text style={styles.sectionTitle}>Upcoming Movies</Text>
        <FlatList
          data={upcomingMovies}
          renderItem={renderMovieItem}
          keyExtractor={(item) => item.id}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.movieList}
        />
      </ScrollView>

      
    </View>
  );
};

export default HomeScreen;