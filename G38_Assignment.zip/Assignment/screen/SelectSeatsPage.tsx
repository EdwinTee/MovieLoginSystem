import React, { useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';

// Define the navigation stack parameter list
type RootStackParamList = {
  CinemaPage: undefined;
  SelectSeatsPage: {
    movieId: string;
    movieTitle: string;
    timeSlot: string;
  };
  ConfirmBookingPage: {
    selectedSeats: string[];
    movieId: string;
    movieTitle: string;
    timeSlot: string;
  };
};

// Define the navigation and route prop types
type NavigationProp = StackNavigationProp<RootStackParamList, 'SelectSeatsPage'>;
type RoutePropType = RouteProp<RootStackParamList, 'SelectSeatsPage'>;

const SelectSeatsPage = () => {
  const navigation = useNavigation<NavigationProp>();
  const route = useRoute<RoutePropType>();
  const { movieId, movieTitle, timeSlot } = route.params;

  const [seats] = useState([
    'A1', 'A2', 'A3', 'A4', 'A5', 'A6',
    'B1', 'B2', 'B3', 'B4', 'B5', 'B6',
    'C1', 'C2', 'C3', 'C4', 'C5', 'C6',
    'D1', 'D2', 'D3', 'D4', 'D5', 'D6',
  ]);
  const soldSeats = ['B3', 'C2', 'C3'];
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);

  const handleSelectSeat = (seat: string) => {
    if (soldSeats.includes(seat)) return;
    setSelectedSeats((prev) =>
      prev.includes(seat) ? prev.filter((s) => s !== seat) : [...prev, seat]
    );
  };

  const handleBookSeats = () => {
    navigation.navigate('ConfirmBookingPage', { selectedSeats, movieId, movieTitle, timeSlot });
  };

  return (
    <View style={styles.container}>
      {/* Movie Info Header */}
      <View style={styles.movieInfo}>
        <Text style={styles.title}>{movieTitle}</Text>
        <Text style={styles.subText}>📅 Showtime: {timeSlot}</Text>
      </View>

      {/* Time Slots */}
      <View style={styles.timeSlots}>
        {['2:45 PM', '3:15 PM', '3:45 PM', '4:15 PM'].map((slot) => (
          <TouchableOpacity
            key={slot}
            style={[
              styles.timeSlotButton,
              slot === timeSlot && styles.timeSlotSelected,
            ]}
          >
            <Text
              style={[
                styles.timeSlotText,
                slot === timeSlot && styles.timeSlotTextSelected,
              ]}
            >
              {slot}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Seat Legend */}
      <View style={styles.legend}>
        <View style={[styles.legendItem, { backgroundColor: 'green' }]} />
        <Text style={styles.legendLabel}>Selected</Text>
        <View style={[styles.legendItem, { backgroundColor: 'red' }]} />
        <Text style={styles.legendLabel}>Sold</Text>
        <View style={[styles.legendItem, { backgroundColor: 'deepskyblue' }]} />
        <Text style={styles.legendLabel}>Available</Text>
      </View>

      {/* Screen Label */}
      <Text style={styles.screenLabel}>SCREEN</Text>

      {/* Seat Grid */}
      <ScrollView contentContainerStyle={styles.seatGrid}>
        {seats.map((seat) => (
          <TouchableOpacity
            key={seat}
            onPress={() => handleSelectSeat(seat)}
            style={[
              styles.seat,
              soldSeats.includes(seat) && styles.soldSeat,
              selectedSeats.includes(seat) && styles.selectedSeat,
            ]}
          >
            <Text style={styles.seatText}>{seat}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Footer */}
      <View style={styles.footer}>
        <Text style={styles.selectedLabel}>
          Your Seat(s): {selectedSeats.join(', ') || 'None'}
        </Text>
        <TouchableOpacity onPress={handleBookSeats} style={styles.bookButton}>
          <Text style={styles.bookButtonText}>BOOK SEAT(S)</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default SelectSeatsPage;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    padding: 16,
  },
  movieInfo: {
    marginBottom: 16,
  },
  title: {
    color: 'red',
    fontSize: 18,
    fontWeight: 'bold',
  },
  subText: {
    color: '#bbb',
    fontSize: 14,
    marginTop: 2,
  },
  timeSlots: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 12,
  },
  timeSlotButton: {
    backgroundColor: '#333',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 20,
  },
  timeSlotText: {
    color: '#fff',
  },
  timeSlotSelected: {
    backgroundColor: 'lightgreen',
  },
  timeSlotTextSelected: {
    color: '#000',
    fontWeight: 'bold',
  },
  legend: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
    gap: 8,
    flexWrap: 'wrap',
  },
  legendItem: {
    width: 20,
    height: 20,
    borderRadius: 4,
    marginHorizontal: 4,
  },
  legendLabel: {
    color: '#fff',
    marginRight: 8,
    fontSize: 12,
  },
  screenLabel: {
    color: '#ccc',
    textAlign: 'center',
    marginVertical: 8,
    fontStyle: 'italic',
  },
  seatGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  seat: {
    width: 40,
    height: 40,
    borderRadius: 8,
    backgroundColor: 'deepskyblue',
    justifyContent: 'center',
    alignItems: 'center',
    margin: 5,
  },
  seatText: {
    color: '#000',
    fontWeight: 'bold',
  },
  soldSeat: {
    backgroundColor: 'red',
  },
  selectedSeat: {
    backgroundColor: 'green',
  },
  footer: {
    marginTop: 16,
    alignItems: 'center',
  },
  selectedLabel: {
    color: '#fff',
    marginBottom: 8,
  },
  bookButton: {
    backgroundColor: 'red',
    paddingVertical: 10,
    paddingHorizontal: 40,
    borderRadius: 30,
  },
  bookButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});