import React from 'react';
import { View, Text, Image, ScrollView, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import styles from './styles'; // Import the styles
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';

type RootStackParamList = {
  MovieDetail: { movie: { id: string; title: string; rating: string; votes: string; genres: string[]; image: any; duration: string; releaseDate: string; description: string } };
  CinemaPage: undefined;
};

type NavigationProp = StackNavigationProp<RootStackParamList, 'MovieDetail'>;

const MovieDetailScreen = ({ route }: { route: any }) => {
  const { movie } = route.params; // Get movie details from route params
  const navigation = useNavigation<NavigationProp>();; // Access navigation

  return (
  <View style={{flex: 1, backgroundColor: 'black'}}>
    <ScrollView style={styles.movieDetailContainer}>
      {/* Movie Poster */}
      <Image source={movie.image} style={styles.movieDetailImage} />

      {/* Movie Title */}
      <Text style={styles.movieDetailTitle}>{movie.title}</Text>

      {/* Movie Duration */}
      <View style={styles.movieDetailRow}>
        <Icon name="time-outline" size={16} color="#fff" />
        <Text style={styles.movieDetailDuration}>{movie.duration}</Text>
      </View>

      {/* Movie Genres */}
      <View style={styles.movieDetailGenreContainer}>
        {movie.genres.map((genre: string, index: number) => (
          <Text key={index} style={styles.movieDetailGenre}>
            {genre}
          </Text>
        ))}
      </View>

      {/* Movie Description */}
      <Text style={styles.movieDetailDescription}>{movie.description}</Text>

      {/* Release Date */}
      <Text style={styles.movieDetailReleaseDate}>
        ⭐ {movie.rating} ({movie.votes}) • {movie.releaseDate}
      </Text>
    </ScrollView>

    {/* Confirm Button */}
    <TouchableOpacity
        style={styles.confirmButton}
        onPress={() => navigation.navigate('CinemaPage')} // Navigate to CinemaPage
      >
        <Text style={styles.confirmButtonText}>Confirm</Text>
      </TouchableOpacity>
    </View>
  );
};

export default MovieDetailScreen;