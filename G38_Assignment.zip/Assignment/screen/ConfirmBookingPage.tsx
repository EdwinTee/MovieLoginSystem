import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';

// Define the navigation stack parameter list
type RootStackParamList = {
  SelectSeatsPage: {
    movieId: string;
    movieTitle: string;
    timeSlot: string;
  };
  ConfirmBookingPage: {
    selectedSeats: string[];
    movieTitle: string;
    timeSlot: string;
  };
  PaymentPage: {
    total: number;
  };
};

// Define the navigation and route prop types
type NavigationProp = StackNavigationProp<RootStackParamList, 'ConfirmBookingPage'>;
type RoutePropType = RouteProp<RootStackParamList, 'ConfirmBookingPage'>;

const ConfirmBookingPage = () => {
  const navigation = useNavigation<NavigationProp>();
  const route = useRoute<RoutePropType>();
  const { selectedSeats, movieTitle, timeSlot } = route.params;

  const [ticketCounts, setTicketCounts] = useState({
    single: 1,
    kids: 0,
    senior: 0,
  });

  const prices = {
    single: 17,
    kids: 10,
    senior: 10,
  };

  const maxTickets = selectedSeats.length;

  const getTotal = () =>
    ticketCounts.single * prices.single +
    ticketCounts.kids * prices.kids +
    ticketCounts.senior * prices.senior;

  const updateCount = (type: keyof typeof ticketCounts, change: number) => {
    const newCount = ticketCounts[type] + change;
    const totalSelected =
      ticketCounts.single + ticketCounts.kids + ticketCounts.senior + change;
    if (newCount >= 0 && totalSelected <= maxTickets) {
      setTicketCounts({ ...ticketCounts, [type]: newCount });
    }
  };

  const handleCheckout = () => {
    navigation.navigate('PaymentPage', { total: getTotal() });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{movieTitle}</Text>
      <Text style={styles.details}>
        {timeSlot} | Seats: {selectedSeats.join(', ')}
      </Text>

      {['single', 'kids', 'senior'].map((type) => (
        <View key={type} style={styles.ticketRow}>
          <Text style={styles.label}>
            {type === 'single'
              ? 'Single'
              : type === 'kids'
              ? 'Kids'
              : 'Senior/OKU'}{' '}
            - RM {prices[type as keyof typeof prices].toFixed(2)}
          </Text>
          <View style={styles.controls}>
            <TouchableOpacity
              onPress={() => updateCount(type as keyof typeof ticketCounts, -1)}
              style={styles.controlBtn}
            >
              <Text>-</Text>
            </TouchableOpacity>
            <Text style={styles.count}>{ticketCounts[type as keyof typeof ticketCounts]}</Text>
            <TouchableOpacity
              onPress={() => updateCount(type as keyof typeof ticketCounts, 1)}
              style={styles.controlBtn}
            >
              <Text>+</Text>
            </TouchableOpacity>
          </View>
        </View>
      ))}

      <Text style={styles.total}>Total: RM {getTotal().toFixed(2)}</Text>

      <TouchableOpacity onPress={handleCheckout} style={styles.checkoutBtn}>
        <Text style={styles.checkoutText}>Checkout</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#000' },
  title: { fontSize: 24, fontWeight: 'bold', color: '#fff', marginBottom: 5 },
  details: { color: '#aaa', marginBottom: 20 },
  ticketRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: 10,
  },
  label: { color: '#fff' },
  controls: { flexDirection: 'row', alignItems: 'center' },
  controlBtn: {
    width: 30,
    height: 30,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 5,
  },
  count: { color: '#fff' },
  total: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'right',
    marginVertical: 20,
  },
  checkoutBtn: {
    backgroundColor: 'red',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  checkoutText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
});

export default ConfirmBookingPage;