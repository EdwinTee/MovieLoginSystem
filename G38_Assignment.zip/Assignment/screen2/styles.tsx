// styles.js
import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    paddingHorizontal: 16,
    paddingTop: 20,
  },

  headerContainer: {
    alignItems: 'center',
    marginBottom: 10,
  },

  movieTitle: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
  },

  cinemaDetails: {
    color: '#ccc',
    fontSize: 16,
    marginTop: 5,
  },

  showtimesLabel: {
    color: '#fff',
    fontSize: 14,
    marginVertical: 10,
  },

  showtimesContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
  },

  showtime: {
    color: '#e50914',
    fontSize: 14,
    textAlign: 'center',
  },

  screenContainer: {
    alignItems: 'center',
    marginVertical: 20,
  },

  screen: {
    width: '70%',
    height: 25,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 5,
  },

  screenLabel: {
    color: '#000',
    fontWeight: 'bold',
  },

  seatArea: {
    paddingBottom: 120,
  },

  seatRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 8,
  },

  rowLabel: {
    color: '#fff',
    marginRight: 10,
    width: 20,
    textAlign: 'right',
    fontWeight: 'bold',
  },

  seat: {
    marginHorizontal: 3,
    padding: 2,
    borderRadius: 4,
  },
  
  seatSelected: {
    backgroundColor: '#1a1a1a',
    borderRadius: 4,
  },

  footerContainer: {
    position: 'absolute',
    bottom: 40,
    left: 20,
    right: 20,
    paddingTop: 10,
    borderTopWidth: 1,
    borderColor: '#444',
    alignItems: 'center',
  },

  selectedSeatsLabel: {
    color: '#fff',
    fontSize: 16,
    marginBottom: 10,
  },

  bookButton: {
    backgroundColor: '#e50914',
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: 'center',
    width: '100%',
  },

  bookButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    textTransform: 'uppercase',
  },
  text: {
    color: '#fff',
    fontSize: 16,
    marginVertical: 6,
  },

  ticketRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#1a1a1a',
    padding: 10,
    marginVertical: 6,
    borderRadius: 8,
  },

  ticketLabel: {
    color: '#fff',
    fontSize: 15,
    flex: 1,
  },

  counterWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: 10,
  },

  counterButton: {
    backgroundColor: '#e50914',
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 6,
  },

  counterText: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
  },

  counterValue: {
    color: '#fff',
    fontSize: 16,
    minWidth: 20,
    textAlign: 'center',
  },

  totalText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    marginVertical: 20,
  },

  button: {
    backgroundColor: '#e50914',
    paddingVertical: 16,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 20,
  },

  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    textTransform: 'uppercase',
  },
  input: {
    backgroundColor: '#f2f2f2',
    paddingVertical: 12,
    paddingHorizontal: 15,
    borderRadius: 10,
    fontSize: 16,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  button: {
    backgroundColor: '#d32f2f', // strong red
    paddingVertical: 15,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5, // Android shadow
    marginTop: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '700',
  },
  addMovieButton: {
    backgroundColor: '#4CAF50',
    marginVertical: 20,
    paddingVertical: 16,
  },

});
