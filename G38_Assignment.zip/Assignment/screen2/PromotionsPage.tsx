import React, { useState } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  Alert,
  StyleSheet
} from 'react-native';
import { styles } from './styles';

const promotions = [
  {
    id: 'promo1',
    title: 'Student Discount',
    description: 'Get 10% off movie tickets with a valid student ID.',
    code: 'STUD10'
  },
  {
    id: 'promo2',
    title: 'Combo Deal',
    description: 'Large popcorn + drink for RM15.',
    code: 'COMBO15'
  },
  {
    id: 'promo3',
    title: 'Family Pack',
    description: 'Buy 4 tickets, get 1 free.',
    code: 'FAMILY5'
  },
  {
    id: 'promo4',
    title: 'Happy Hour',
    description: '50% off on all beverages before 5 PM.',
    code: 'HAPPY50'
  },
];

export function PromotionsPage() {
  // track which promos are expanded
  const [expandedIds, setExpandedIds] = useState({});

  const toggleExpand = id => {
    setExpandedIds(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const showCode = (title, code) => {
    Alert.alert(title, `Use this code: ${code}`);
  };

  return (
    <View style={styles.container}>
      <Text style={[styles.text, { fontSize: 22, fontWeight: 'bold', marginBottom: 10 }]}>
        🎉 Promotions
      </Text>

      <FlatList
        data={promotions}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <View>
            <TouchableOpacity
              style={promoStyles.promotionItem}
              onPress={() => toggleExpand(item.id)}
            >
              <Text style={promoStyles.title}>{item.title}</Text>
              <Text style={promoStyles.description}>{item.description}</Text>
            </TouchableOpacity>

            {expandedIds[item.id] && (
              <View style={promoStyles.dropdown}>
                <TouchableOpacity
                  style={promoStyles.codeButton}
                  onPress={() => showCode(item.title, item.code)}
                >
                  <Text style={promoStyles.codeButtonText}>Show Code</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        )}
      />
    </View>
  );
}

const promoStyles = StyleSheet.create({
  promotionItem: {
    backgroundColor: '#1a1a1a',
    padding: 15,
    borderRadius: 8,
    marginVertical: 8,
  },
  title: {
    color: '#e50914',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  description: {
    color: '#fff',
    fontSize: 14,
  },

  dropdown: {
    backgroundColor: '#2a2a2a',
    marginHorizontal: 15,
    padding: 10,
    borderBottomLeftRadius: 8,
    borderBottomRightRadius: 8,
  },
  codeButton: {
    backgroundColor: '#e50914',
    paddingVertical: 10,
    borderRadius: 6,
    alignItems: 'center',
  },
  codeButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});
