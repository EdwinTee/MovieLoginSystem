import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { UserProvider, useUser } from './screens1/UserContext';

// Import all your screens
import LoginScreen from "./screens1/LoginScreen";
import ForgotPasswordScreen from "./screens1/ForgotPasswordScreen";
import SignUpScreen from "./screens1/SignUpScreen";
import VerificationScreen from './screens1/VerificationScreen';
import ResetPasswordScreen from './screens1/ResetPasswordScreen';
import HomeScreen from './screen/HomeScreen';
import MovieDetailScreen from './screen/MovieDetailScreen';
import CinemaPage from './screen/CinemaPage';
import SelectSeatsPage from './screen/SelectSeatsPage';
import ConfirmBookingPage from './screen/ConfirmBookingPage';
import PaymentPage from './screen/PaymentPage';
import ProfileScreen from "./screens1/ProfileScreen";
import EditProfile from './screens1/EditProfile';
import SearchScreen from './screen/SearchScreen';
import { PromotionsPage } from './screen2/PromotionsPage';


// Create navigators
const AuthStack = createStackNavigator();
const HomeStack = createStackNavigator();
const ProfileStack = createStackNavigator();
const Tab = createBottomTabNavigator();
const RootStack = createStackNavigator();

// Auth Stack Navigator
const AuthStackNavigator = () => (
  <AuthStack.Navigator
    screenOptions={{
      headerStyle: { backgroundColor: 'red' },
      headerTintColor: '#fff',
      headerTitleStyle: { fontWeight: 'bold' }
    }}
  >
    <AuthStack.Screen name="Login" component={LoginScreen} />
    <AuthStack.Screen name="SignUp" component={SignUpScreen} />
    <AuthStack.Screen name="ForgotPassword" component={ForgotPasswordScreen} />
    <AuthStack.Screen name="Verification" component={VerificationScreen} />
    <AuthStack.Screen name="ResetPassword" component={ResetPasswordScreen} />
  </AuthStack.Navigator>
);

// Home Stack Navigator
const HomeStackNavigator = () => (
  <HomeStack.Navigator screenOptions={{ headerShown: false }}>
    <HomeStack.Screen name="Home" component={HomeScreen} />
    <HomeStack.Screen name="MovieDetail" component={MovieDetailScreen} />
    <HomeStack.Screen name="CinemaPage" component={CinemaPage} />
    <HomeStack.Screen name="SelectSeatsPage" component={SelectSeatsPage} />
    <HomeStack.Screen name="ConfirmBookingPage" component={ConfirmBookingPage} />
    <HomeStack.Screen name="PaymentPage" component={PaymentPage} />
  </HomeStack.Navigator>
);

// Profile Stack Navigator
const ProfileStackNavigator = () => (
  <ProfileStack.Navigator
    screenOptions={{
      headerStyle: { backgroundColor: 'red' },
      headerTintColor: '#fff'
    }}
  >
    <ProfileStack.Screen 
      name="ProfileMain" 
      component={ProfileScreen} 
      options={{ headerShown: false }} 
    />
    <ProfileStack.Screen 
      name="EditProfile" 
      component={EditProfile} 
      options={{ title: 'Edit Profile' }} 
    />
  </ProfileStack.Navigator>
);

// Main Tab Navigator
const MainTabNavigator = () => {
  return (
    <Tab.Navigator
      initialRouteName="HomeTab"
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName;

          if (route.name === 'HomeTab') {
            iconName = focused ? 'home' : 'home-outline';
          } else if (route.name === 'SearchTab') {
            iconName = focused ? 'search' : 'search-outline';
          } else if (route.name === 'PromotionTab') {
            iconName = focused ? 'ticket' : 'ticket-outline';
          } else if (route.name === 'ProfileTab') {
            iconName = 'person-circle-outline';
          }

          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: 'red',
        tabBarInactiveTintColor: 'gray',
        tabBarStyle: {
          backgroundColor: '#000',
          borderTopWidth: 0,
          paddingBottom: 5,
          height: 60,
        },
        headerShown: false,
      })}
    >
      <Tab.Screen 
        name="HomeTab" 
        component={HomeStackNavigator} 
        options={{ title: 'Home' }} 
      />
      <Tab.Screen 
        name="SearchTab" 
        component={SearchScreen} 
        options={{ title: 'Search' }} 
      />
      <Tab.Screen 
        name="PromotionTab" 
        component={PromotionsPage} 
        options={{ title: 'Promotions' }}
      />
      <Tab.Screen 
        name="ProfileTab" 
        component={ProfileStackNavigator} 
        options={{ title: 'Profile' }} 
      />
    </Tab.Navigator>
  );
};

// Root Navigator
const AppNavigator = () => {
  const { user } = useUser();

  return (
    <RootStack.Navigator initialRouteName="MainApp" screenOptions={{ headerShown: false }}>
      {user ? (
        <RootStack.Screen name="MainApp" component={MainTabNavigator} />
      ) : (
        <RootStack.Screen name="Auth" component={AuthStackNavigator} />
      )}
    </RootStack.Navigator>
  );
};

// Main App Component
export default function App() {
  return (
    <UserProvider>
      <NavigationContainer>
        <AppNavigator />
      </NavigationContainer>
    </UserProvider>
  );
}