from flask import Flask, jsonify, request
import random
import string
from datetime import datetime, timedelta

app = Flask(__name__)

# In-memory storage
verification_data = {}

@app.route('/api/send-code', methods=['POST'])
def send_code():
    email = request.json.get('email')
    if not email:
        return jsonify({'success': False, 'message': 'Email required'}), 400
    
    code = ''.join(random.choices(string.digits, k=6))
    expires = datetime.now() + timedelta(minutes=5)
    
    verification_data[email] = {
        'code': code,
    }
    
    print(f"Code for {email}: {code} (expires {expires})")
    return jsonify({'success': True}), 200

@app.route('/api/verify-code', methods=['POST'])
def verify_code():
    data = request.json
    if not data or 'email' not in data or 'code' not in data:
        return jsonify({'success': False}), 400
        
    record = verification_data.get(data['email'])
    if not record:
        return jsonify({'success': False}), 404
          
    if record['code'] != data['code']:
        return jsonify({'success': False}), 403
        
    return jsonify({'success': True}), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=True)