import React, {useEffect} from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Alert, Image } from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useUser } from './UserContext';
import { SharedStyles } from './styles';

const DEFAULT_PROFILE_IMAGE = require("../android/app/src/main/assets/images.jpg");

const ProfileScreen = ({navigation}) => {
  const { user, logout } = useUser();

    useEffect(() => {
    if (!user) {
      navigation.navigate('Home');
    }
  }, [user]);

  if (!user) return null;

  const handleLogout = () => {
    Alert.alert(
      'Log Out',
      'Are you sure you want to log out?',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Log Out',
          style: 'destructive',
          onPress: () => {
            logout();
          },
        },
      ],
      { cancelable: false }
    );
  };

  return (
    <View style={styles.profileContainer}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>My Account</Text>
        <MaterialCommunityIcons 
          name="home" 
          size={24} 
          color="white" 
          onPress={() => navigation.navigate('Home')}
        />
      </View>

      {/* Profile Section */}
      <View style={styles.profileSection}>
        <View style={styles.profileImageContainer}>
            <Image 
              source={user?.profileImage || DEFAULT_PROFILE_IMAGE} 
              style={styles.profileImage}
            />
        </View>
            <Text style={styles.usernameText}>{user.username}</Text>    
      </View>

      {/* Content Sections */}
      <ScrollView contentContainerStyle={styles.menu}>
        <Text style={styles.sectionTitle}>GENERAL</Text>
        
        <View style={styles.buttonRow}>
          <MenuButton 
            title="Edit Profile"
            icon="account-edit"
            onPress={() => navigation.navigate('EditProfile')}
          />
          <MenuButton 
            title="My Tickets"
            icon="ticket"
          />
        </View>
        
        {/*<View style={styles.buttonRow}>
          <MenuButton 
            title="My Rewards"
            icon="gift"
          />
        </View>*/}
        
        {/* Logout Button at bottom of scrollable area */}
        <View style={styles.linkContainer}>
          {user && (
            <TouchableOpacity 
              style={styles.logoutButton} 
              onPress={handleLogout}
            >
              <Text style={styles.logoutText}>Log Out</Text>
            </TouchableOpacity>
          )}
        </View>
      </ScrollView>
    </View>
  );
};

const MenuButton = ({ title, icon, onPress }) => (
  <TouchableOpacity style={styles.menuButton} onPress={onPress}>
    <MaterialCommunityIcons name={icon} size={24} color="red" />
    <Text style={styles.menuButtonText}>{title}</Text>
  </TouchableOpacity>
);

const styles = StyleSheet.create({
  ...SharedStyles,
  profileContainer: {
    flex: 1,
  },
  header: {
    paddingTop: 10,
    paddingHorizontal: 20,
    paddingBottom: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'red'
  },
  headerTitle: {
    fontSize: 20,
    color: '#fff',
    fontWeight: 'bold'
  },
  profileSection: {
    alignItems: 'center',
    paddingVertical: 30,
    backgroundColor: 'red'
  },
  usernameText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  logoutButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: 'red',
    paddingVertical: 8,
    paddingHorizontal: 30,
    borderRadius: 8
  },
  logoutText: {
    color: 'red',
    fontSize: 14
  },
  menu: {
    flex: 1,
    paddingHorizontal: 20,
    backgroundColor: '#000',
    paddingTop: 20,
    paddingBottom: 20
  },
  sectionTitle: {
    color: '#aaa',
    fontSize: 21,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 15,
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15
  },
  menuButton: {
    backgroundColor: '#222',
    borderRadius: 10,
    padding: 20,
    width: '45%',
    alignItems: 'center',
    justifyContent: 'center'
  },
  menuButtonText: {
    color: 'white',
    fontSize: 16,
    marginTop: 10,
    textAlign: 'center'
  },
  profileImageContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    overflow: 'hidden' 
  },
  profileImage: {
    width: '100%',
    height: '100%',
  },
});

export default ProfileScreen;