import React, { useState, useEffect } from 'react';
import { View, Text, TextInput,  StyleSheet,  TouchableOpacity, Alert} from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { getUserProfile, updateUserProfile } from './db-service';
import { useUser } from './UserContext';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import DateTimePicker from '@react-native-community/datetimepicker';
import { SharedStyles } from './styles';

const EditProfileScreen = () => {
  const { user } = useUser();
  const [profile, setProfile] = useState({
    username: '',
    phone: '',
    gender: 'male',
    date_of_birth: ''
  });
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [tempDate, setTempDate] = useState(new Date());

  useEffect(() => {
    const loadProfile = async () => {
      if (user?.id) {
        try {
          const userProfile = await getUserProfile(user.id);
          if (userProfile) {
            setProfile({
              username: userProfile.username || '',
              phone: userProfile.phone || '',
              gender: userProfile.gender || 'male',
              date_of_birth: userProfile.date_of_birth || ''
            });
            if (userProfile.date_of_birth) {
              setTempDate(new Date(userProfile.date_of_birth));
            }
          }
        } catch (error) {
          console.error('Failed to load profile:', error);
          Alert.alert('Error', 'Failed to load profile data');
        }
      }
    };

    loadProfile();
  }, [user]);

  const validateForm = () => {
    if (!profile.username.trim()) {
      Alert.alert('Error', 'Username is required');
      return false;
    }

    if (profile.phone && !/^[0-9]{10,11}$/.test(profile.phone)) {
      Alert.alert('Error', 'Phone number must be 10-11 digits');
      return false;
    }

    return true;
  };

  const handleDateChange = (event: any, selectedDate?: Date) => {
    setShowDatePicker(false);
    if (selectedDate) {
      setTempDate(selectedDate);
      setProfile({
        ...profile,
        date_of_birth: selectedDate.toISOString().split('T')[0]
      });
    }
  };

  const handleSave = async () => {
    if (!validateForm()) return;
    if (!user?.id) return;

    try {
      await updateUserProfile(user.id, profile);
      Alert.alert('Success', 'Profile updated successfully');
    } catch (error) {
      console.error('Error updating profile:', error);
      Alert.alert('Error', 'Failed to update profile');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Username</Text>
      <TextInput
        style={styles.input}
        value={profile.username}
        onChangeText={(text) => setProfile({...profile, username: text})}
      />

      <Text style={styles.label}>Phone</Text>
      <TextInput
        style={styles.input}
        value={profile.phone}
        onChangeText={(text) => {
          const formattedText = text.replace(/[^0-9]/g, '');
          setProfile({...profile, phone: formattedText});
        }}
        maxLength={11}
      />

      <Text style={styles.label}>Gender</Text>
      <View style={styles.pickerContainer}>
        <Picker
          selectedValue={profile.gender}
          onValueChange={(itemValue) => 
            setProfile({...profile, gender: itemValue})
          }
          style={styles.picker}
        >
          <Picker.Item label="Male" value="male" />
          <Picker.Item label="Female" value="female" />
        </Picker>
      </View>

      <Text style={styles.label}>Date of Birth</Text>
      <TouchableOpacity 
        style={styles.dateInput}
        onPress={() => setShowDatePicker(true)}
      >
        <Text style={profile.date_of_birth ? styles.dateText : styles.placeholderText}>
          {profile.date_of_birth || 'Select date'}
        </Text>
        <MaterialCommunityIcons name="calendar" size={24} color="red" />
      </TouchableOpacity>
      {showDatePicker && (
        <DateTimePicker
          value={tempDate}
          mode="date"
          display="default"
          onChange={handleDateChange}
          maximumDate={new Date()}
        />
      )}
      <View style={styles.linkContainer}>
      <TouchableOpacity 
        style={styles.saveButton} 
        onPress={handleSave}
      >
        <Text style={styles.buttonText}>Save Changes</Text>
      </TouchableOpacity>
    </View>
    </View>
  );
};

const styles = StyleSheet.create({
  ...SharedStyles,
  pickerContainer: {
    ...SharedStyles.input,
    padding: 0,
    justifyContent: 'center',
    height: 50,
    marginBottom: 15,
  },
  picker: {
    height: '100%',
    width: '100%',
  },
  dateInput: {
    ...SharedStyles.input,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
  },
  dateText: {
    fontSize: 16,
    color: '#333',
  },
  placeholderText: {
    fontSize: 16,
    color: '#999',
  },
  saveButton: {
    ...SharedStyles.button,
    marginTop: 20,
  },
});

export default EditProfileScreen;