import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  Alert,
  ScrollView
} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { checkUserExists, createUser } from './db-service';
import { SharedStyles } from './styles';

const SignUpScreen = ({navigation}) => {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    isAgreed: false
  });

  const validateField = async (name: string, value: string) => {
    switch(name) {
      case 'email':
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
          Alert.alert('Error', 'Invalid email format');
          return false;
        } else {
          const { emailExists } = await checkUserExists(value);
          if (emailExists) {
            Alert.alert('Error', 'Email already registered');
            return false;
          }
        }
        break;
      case 'password':
        if (value.length < 8) {
          Alert.alert('Error', 'Password must be at least 8 characters');
          return false;
        } else if (!/(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[^a-zA-Z0-9])/.test(value)) {
          Alert.alert('Error', 'Password requires letter, number & special character');
          return false;
        }
        break;
      case 'confirmPassword':
        if (value !== formData.password) {
          Alert.alert('Error', 'Passwords do not match');
          return false;
        }
        break;
    }
    return true;
  };

  const handleChange = (name: string, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async () => {
    if (!formData.isAgreed) {
      Alert.alert('Error', 'Please agree to the terms');
      return;
    }

    const validations = await Promise.all([
      validateField('email', formData.email),
      validateField('password', formData.password),
      validateField('confirmPassword', formData.confirmPassword)
    ]);

    if (!validations.every(v => v)) return;

    try {
      await createUser(formData.email, formData.password);
      Alert.alert('Success', 'Account created successfully!');
      navigation.navigate('Login');
    } catch (error) {
      console.error('Signup error:', error);
      Alert.alert('Error', 'Failed to create account. Please try again.');
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.scrollContainer}>
      <Text style={styles.title}>Create Account</Text>

      {/* Email */}
      <Text style={styles.label}>Email Address</Text>
      <TextInput
        style={styles.input}
        value={formData.email}
        onChangeText={text => handleChange('email', text)}
        onBlur={() => validateField('email', formData.email)}
      />

      {/* Password */}
      <Text style={styles.label}>Password</Text>
      <TextInput
        style={styles.input}
        secureTextEntry
        value={formData.password}
        onChangeText={text => handleChange('password', text)}
        onBlur={() => validateField('password', formData.password)}
      />

      {/* Confirm Password */}
      <Text style={styles.label}>Confirm Password</Text>
      <TextInput
        style={styles.input}
        secureTextEntry
        value={formData.confirmPassword}
        onChangeText={text => handleChange('confirmPassword', text)}
        onBlur={() => validateField('confirmPassword', formData.confirmPassword)}
      />

      {/* Terms */}
      <View style={styles.checkboxContainer}>
        <TouchableOpacity onPress={() => setFormData({...formData, isAgreed: !formData.isAgreed})}>
          <MaterialCommunityIcons
            name={formData.isAgreed ? "checkbox-marked" : "checkbox-blank-outline"}
            size={24}
            color='red'
          />
        </TouchableOpacity>
        <Text style={styles.agreeText}>
          I agree to the Terms & Conditions
        </Text>
      </View>

      {/* Submit Button */}
      <View style={styles.linkContainer}>
      <TouchableOpacity
        style={[styles.button, !formData.isAgreed && styles.disabledButton]}
        onPress={handleSubmit}
        disabled={!formData.isAgreed}
      >
        <Text style={styles.buttonText}>Create Account</Text>
      </TouchableOpacity>
      </View>

      {/* Login Link */}
      <View style={styles.linkContainer}>
        <Text style={styles.linkText}>Already have an account? </Text>
        <TouchableOpacity onPress={() => navigation.navigate('Login')}>
          <Text style={styles.linkButton}>Login</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  ...SharedStyles,
  agreeText: {
    color: 'white',
    fontSize: 14,
    flex: 1,
  },
});

export default SignUpScreen;