import { openDatabase, enablePromise } from 'react-native-sqlite-storage';

enablePromise(true);

const databaseName = 'userdb.sqlite';
let dbInstance: any = null;

export const getDBConnection = async () => {
  if (!dbInstance) {
    try {
      dbInstance = await openDatabase({
        name:`${databaseName}`, createFromLocation:`~${databaseName}`,
      });
    } catch (error) {
      console.error('Failed to open database:', error);
      throw new Error('Database connection failed');
    }
  }
  return dbInstance;
};

export const checkUserExists = async (email: string) => {
  const db = await getDBConnection();
  try {
    const [result] = await db.executeSql(
      'SELECT 1 FROM users WHERE email = ? LIMIT 1',
      [email]
    );
    return { emailExists: result.rows.length > 0 };
  } catch (error) {
    console.error('Error checking user existence:', error);
    throw new Error('Failed to check user existence');
  }
};

export const createUser = async (email: string, password: string): Promise<number> => {
  const db = await getDBConnection();
  try {
    const [result] = await db.executeSql(
      'INSERT INTO users (email, password) VALUES (?, ?)',
      [email, password]
    );
    return result.insertId;
  } catch (error) {
    console.error('Error creating user:', error);
    if (error.message.includes('UNIQUE constraint failed')) {
      throw new Error('Email already exists');
    }
    throw new Error('Failed to create user');
  }
};

export const updateUserPassword = async (email: string, newPassword: string) => {
    try {
        const db = await getDBConnection();
        const [result] = await db.executeSql(
            'UPDATE users SET password = ? WHERE email = ?',
            [newPassword, email]
        );;
        return result.rowsAffected > 0;
    } catch (error) {
        throw error;
    }
};

export const getUserProfile = async (userId: number): Promise<UserProfile | null> => {
  const db = await getDBConnection();
  try {
    const [result] = await db.executeSql(
      `SELECT u.id, u.email, up.username, up.phone, up.gender, up.date_of_birth 
       FROM users u
       LEFT JOIN user_profiles up ON u.id = up.id
       WHERE u.id = ?`,
      [userId]
    );
    return result.rows.length > 0 ? result.rows.item(0) : null;
  } catch (error) {
    console.error('Error getting user profile:', error);
    throw new Error('Failed to get user profile');
  }
};

export const updateUserProfile = async (userId: number, profile: Partial<UserProfile>): Promise<boolean> => {
  const db = await getDBConnection();
  try {
    await db.executeSql('BEGIN TRANSACTION');

    const [checkResult] = await db.executeSql(
      'SELECT 1 FROM user_profiles WHERE id = ?',
      [userId]
    );

    if (checkResult.rows.length > 0) {
      await db.executeSql(
        `UPDATE user_profiles SET 
          username = ?,
          phone = ?,
          gender = ?,
          date_of_birth = ?
        WHERE id = ?`,
        [
          profile.username,
          profile.phone,
          profile.gender,
          profile.date_of_birth,
          userId
        ]
      );
    } else {
      await db.executeSql(
        `INSERT INTO user_profiles 
          (id, username, phone, gender, date_of_birth) 
        VALUES (?, ?, ?, ?, ?)`,
        [
          userId,
          profile.username,
          profile.phone,
          profile.gender,
          profile.date_of_birth
        ]
      );
    }

    await db.executeSql('COMMIT');
    return true;
  } catch (error) {
    await db.executeSql('ROLLBACK');
    console.error('Error updating profile:', error);
    throw new Error('Failed to update profile');
  }
};

export const verifyUser = async (email: string, password: string): Promise<UserProfile | null> => {
    const db = await getDBConnection();
    try {
      const [result] = await db.executeSql(
        `SELECT u.id, u.email, up.username, up.phone, up.gender, up.date_of_birth 
         FROM users u
         LEFT JOIN user_profiles up ON u.id = up.id
         WHERE u.email = ? AND u.password = ?`,
        [email, password]
      );
      
      if (result.rows.length > 0) {
        return result.rows.item(0);
      }
      return null;
    } catch (error) {
      console.error('Error verifying user:', error);
    }
  };