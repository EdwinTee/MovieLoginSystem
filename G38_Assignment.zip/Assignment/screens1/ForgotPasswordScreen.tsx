import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { getDBConnection } from './db-service';
import { SharedStyles } from './styles';

const ForgotPasswordScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');

  const validateEmail = (email) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  };

  // Make this function async
  const handleSend = async () => {
    if (!email) {
      Alert.alert('Error', 'Email is required');
      return;
    }
    
    if (!validateEmail(email)) {
      Alert.alert('Error', 'Please enter a valid email address');
      return;
    }

    try {
      const db = await getDBConnection();
      const query = 'SELECT * FROM users WHERE email = ?';
      const results = await db.executeSql(query, [email]);
      
      if (results[0].rows.length === 0) {
        Alert.alert('Error', 'No account found with this email');
        return;
      }

      Alert.alert('Success', 'Verification code sent to your email');
      navigation.navigate('Verification', { email });
    } catch (error) {
      Alert.alert('Error', 'Failed to verify email');
      console.error(error);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.title}>Forgot Password</Text>
        <Text style={styles.subtitle}>
          Enter your email address and we'll send you a code to reset your password.
        </Text>

        <TextInput
          style={styles.input}
          value={email}
          onChangeText={setEmail}
        />
        <View style={styles.linkContainer}>
        <TouchableOpacity
          style={[styles.button, !email && styles.disabledButton]}
          onPress={handleSend}
          disabled={!email}
        >
          <Text style={styles.buttonText}>Send</Text>
        </TouchableOpacity>
        </View>

        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backButtonText}>Back to Sign in</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  ...SharedStyles,
  backButton: {
    padding: 15,
    alignItems: 'center',
  },
  backButtonText: {
    color: 'red',
    fontSize: 16,
  },
});

export default ForgotPasswordScreen;