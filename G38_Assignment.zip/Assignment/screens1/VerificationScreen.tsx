import React, { useState, useRef, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { SharedStyles } from './styles';

const VerificationScreen = ({ route, navigation }) => {
  const { email } = route.params;
  const [code, setCode] = useState(['', '', '', '', '', '']); // 6-digit code
  const [resendDisabled, setResendDisabled] = useState(false);
  const [countdown, setCountdown] = useState(30);
  const inputRefs = Array(6).fill(0).map(() => useRef());

  // Request verification code when screen loads
  useEffect(() => {
    requestVerificationCode();
  }, []);

  // Countdown timer for resend
  useEffect(() => {
    let timer;
    if (resendDisabled && countdown > 0) {
      timer = setInterval(() => setCountdown(prev => prev - 1), 1000);
    } else if (countdown === 0) {
      setResendDisabled(false);
      setCountdown(30);
    }
    return () => clearInterval(timer);
  }, [resendDisabled, countdown]);

  const requestVerificationCode = async () => {
    setResendDisabled(true);
    
    try {
      const response = await fetch('http://10.0.2.2:5000/api/send-code', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Failed to send code');
      }
    } catch (error) {
      Alert.alert('Error', error.message);
      setResendDisabled(false);
    }
  };

  const handleCodeChange = (text, index) => {
    const numericText = text.replace(/[^0-9]/g, '');
    const newCode = [...code];
    newCode[index] = numericText;
    setCode(newCode);

    if (numericText && index < 5) {
      inputRefs[index + 1].current.focus();
    }
  };

  const handleVerify = async () => {
    const verificationCode = code.join('');
    
    if (verificationCode.length !== 6) {
      Alert.alert('Error', 'Please enter complete 6-digit code');
      return;
    }
    
    try {
      const response = await fetch('http://10.0.2.2:5000/api/verify-code', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, code: verificationCode }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Verification failed');
      }

      Alert.alert('Success', 'Verification successful!');
      navigation.navigate('ResetPassword', { email });
    } catch (error) {
      Alert.alert('Error', error.message);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Enter Verification Code</Text>
      <Text style={styles.subtitle}>Sent to {email}</Text>

      <View style={styles.codeContainer}>
        {code.map((digit, index) => (
          <TextInput
            key={index}
            ref={inputRefs[index]}
            style={styles.codeInput}
            maxLength={1}
            value={digit}
            onChangeText={(text) => handleCodeChange(text, index)}
          />
        ))}
      </View>
      <View style={styles.linkContainer}>
      <TouchableOpacity
        style={styles.button}
        onPress={handleVerify}
      >
        <Text style={styles.buttonText}>Verify</Text>
      </TouchableOpacity>
      </View>
      <TouchableOpacity
        onPress={requestVerificationCode}
        disabled={resendDisabled}
      >
        <Text style={[styles.resendText, resendDisabled && styles.disabledText]}>
          {resendDisabled ? `Resend code in ${countdown}s` : 'Resend code'}
        </Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
...SharedStyles,
  resendText: {
    marginTop: 20,
    color: 'red',
    textAlign: 'center',
  },
  disabledText: {
    color: '#aaa',
  },
});

export default VerificationScreen;